package classes;

public abstract class Bike {
	abstract void run();
}

/*
public class Honda extend Bike() {
	void run(){
		System.out.println("running safely");
	}
	
	// abstract classes can have non abstract methods
}
*/
