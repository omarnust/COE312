package classes;

public class Dog extends Mammal implements Pet{
	
	public void walk() {
		
	}

}
